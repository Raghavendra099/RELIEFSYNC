# ReliefSync AI — Phase 1 Setup

AI-powered crisis coordination platform · React + Firebase + Gemini

---

## Quick Start (5 steps)

### 1. Create your Firebase project
1. Go to https://console.firebase.google.com
2. Click "Add project" → name it `reliefsync-ai`
3. Disable Google Analytics (not needed for MVP)

### 2. Enable services in Firebase console
- **Authentication** → Sign-in method → Enable "Google"
- **Firestore Database** → Create database → Start in **test mode**
- **Hosting** → Get started (click through the wizard)

### 3. Get your Firebase config
- Firebase Console → Project Settings → Your Apps → Add web app
- Copy the `firebaseConfig` object
- Paste it into `src/firebase/config.js`

### 4. Install and run locally
```bash
npm install
npm run dev
```
App runs at http://localhost:5173

### 5. Seed demo data (for hackathon demo)
```bash
# Add your firebaseConfig to seed.js first, then:
node seed.js
```
This creates 8 volunteers + 5 crisis reports in Gadag/Karnataka.

---

## Deploy to Firebase Hosting
```bash
npm install -g firebase-tools
firebase login
firebase init          # select Hosting + Firestore
npm run build
firebase deploy
```
Your app is live at: `https://YOUR_PROJECT_ID.web.app`

---

## Project Structure
```
reliefsync/
├── src/
│   ├── firebase/
│   │   ├── config.js       ← PUT YOUR FIREBASE CONFIG HERE
│   │   └── firestore.js    ← All Firestore helpers
│   ├── hooks/
│   │   └── useAuth.js      ← Google Auth hook
│   ├── pages/
│   │   ├── Login.jsx       ← Google sign-in
│   │   ├── Dashboard.jsx   ← Live crisis overview
│   │   ├── ReportInput.jsx ← Text/voice/CSV submission
│   │   └── TaskAssignment.jsx ← Volunteer matching
│   ├── components/
│   │   └── ProtectedRoute.jsx
│   ├── styles/
│   │   └── global.css
│   ├── App.jsx
│   └── main.jsx
├── firestore.rules         ← Security rules
├── firebase.json           ← Hosting config
├── seed.js                 ← Demo data seeder
└── package.json
```

---

## Next Steps (Phase 2 → Phase 3)
- Phase 2: Add Gemini AI Cloud Function to auto-classify reports
- Phase 3: Add Google Maps heatmap to dashboard
- Phase 4: Add FCM push notifications for volunteers

---

## Tech Stack
| Layer     | Tech                          |
|-----------|-------------------------------|
| Frontend  | React 18 + Vite               |
| Auth      | Firebase Authentication (Google) |
| Database  | Firestore (real-time)         |
| Hosting   | Firebase Hosting              |
| AI (next) | Gemini API via Cloud Functions|
| Maps (next)| Google Maps JS API           |
