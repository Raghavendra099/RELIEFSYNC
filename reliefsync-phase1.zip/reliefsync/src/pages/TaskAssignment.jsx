// src/pages/TaskAssignment.jsx

import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { listenReports, getVolunteers, createAssignment } from "../firebase/firestore";

function haversineKm(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return Math.round(R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

const CAT_COLOR = { food:"#1D9E75", medical:"#E24B4A", shelter:"#378ADD" };

export default function TaskAssignment() {
  const navigate = useNavigate();
  const location = useLocation();
  const [reports, setReports] = useState([]);
  const [volunteers, setVolunteers] = useState([]);
  const [selected, setSelected] = useState(location.state?.report || null);
  const [assigning, setAssigning] = useState(false);
  const [done, setDone] = useState(false);

  useEffect(() => {
    const unsub = listenReports((r) =>
      setReports(r.filter((rep) => rep.status !== "resolved"))
    );
    getVolunteers().then(setVolunteers);
    return unsub;
  }, []);

  // Find best-matched volunteers for selected report
  const matches = selected
    ? volunteers
        .filter((v) => v.available && v.skills?.includes(selected.category))
        .map((v) => ({
          ...v,
          distance: selected.lat
            ? haversineKm(selected.lat, selected.lng, v.lat, v.lng)
            : Math.floor(Math.random() * 12 + 1), // demo fallback
        }))
        .sort((a, b) => a.distance - b.distance)
        .slice(0, 3)
    : [];

  async function assign(volunteer) {
    setAssigning(true);
    await createAssignment(selected.id, volunteer.id, volunteer.name);
    setAssigning(false);
    setDone(true);
    setTimeout(() => { setDone(false); setSelected(null); }, 2000);
  }

  return (
    <div className="rs-layout">
      <aside className="rs-sidebar">
        <div className="rs-logo" style={{marginBottom:"2rem"}}>
          <span className="rs-logo-icon">⚡</span>
          <span className="rs-logo-text">ReliefSync</span>
        </div>
        <nav className="rs-nav">
          <button className="rs-nav-item" onClick={() => navigate("/dashboard")}>Dashboard</button>
          <button className="rs-nav-item" onClick={() => navigate("/report")}>Submit Report</button>
          <button className="rs-nav-item rs-nav-active">Task Assignment</button>
        </nav>
      </aside>

      <main className="rs-main">
        <header className="rs-page-header">
          <div>
            <h1 className="rs-page-title">Task assignment</h1>
            <p className="rs-page-sub">AI-matched volunteers · skill + distance ranked</p>
          </div>
        </header>

        <div className="rs-two-col">
          {/* Reports list */}
          <div>
            <div className="rs-section-title">Pending reports</div>
            {reports.filter(r => r.status === "classified" || r.status === "pending").map((r) => (
              <div
                key={r.id}
                className={`rs-report-row rs-clickable ${selected?.id === r.id ? "rs-selected" : ""}`}
                onClick={() => { setSelected(r); setDone(false); }}
              >
                <div
                  className="rs-cat-badge"
                  style={{
                    background: (CAT_COLOR[r.category] ?? "#888") + "22",
                    color: CAT_COLOR[r.category] ?? "#888",
                    borderColor: (CAT_COLOR[r.category] ?? "#888") + "44",
                  }}
                >
                  {r.category ?? "Unclassified"}
                </div>
                <p className="rs-report-text">{r.text?.slice(0, 70)}…</p>
                {r.urgencyScore && (
                  <span className="rs-urgency-mini">Urgency {r.urgencyScore}/10</span>
                )}
              </div>
            ))}
            {reports.length === 0 && <div className="rs-empty">No pending reports.</div>}
          </div>

          {/* Volunteer matches */}
          <div>
            <div className="rs-section-title">
              {selected ? "Suggested volunteers" : "Select a report to see matches"}
            </div>

            {done && (
              <div className="rs-success-banner">Volunteer assigned successfully!</div>
            )}

            {selected && !done && matches.length === 0 && (
              <div className="rs-empty">No available volunteers match this category.</div>
            )}

            {selected && !done && matches.map((v, i) => (
              <div key={v.id} className="rs-volunteer-card">
                <div className="rs-vol-avatar">{v.name?.[0] ?? "V"}</div>
                <div className="rs-vol-info">
                  <span className="rs-vol-name">{v.name}</span>
                  <div className="rs-vol-tags">
                    {v.skills?.map((s) => (
                      <span key={s} className="rs-skill-tag">{s}</span>
                    ))}
                    <span className="rs-dist-tag">{v.distance} km away</span>
                  </div>
                </div>
                <button
                  className={`rs-assign-btn ${i === 0 ? "rs-assign-btn--primary" : ""}`}
                  onClick={() => assign(v)}
                  disabled={assigning}
                >
                  {i === 0 ? "Best match" : "Assign"}
                </button>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
