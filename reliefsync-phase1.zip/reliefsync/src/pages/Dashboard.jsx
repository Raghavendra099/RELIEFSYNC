// src/pages/Dashboard.jsx

import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { listenReports, listenVolunteers } from "../firebase/firestore";

const CATEGORY_COLOR = {
  food: "#1D9E75",
  medical: "#E24B4A",
  shelter: "#378ADD",
  null: "#888780",
};

const CATEGORY_LABEL = {
  food: "Food",
  medical: "Medical",
  shelter: "Shelter",
  null: "Unclassified",
};

export default function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [reports, setReports] = useState([]);
  const [volunteers, setVolunteers] = useState([]);

  useEffect(() => {
    const unsub1 = listenReports(setReports);
    const unsub2 = listenVolunteers(setVolunteers);
    return () => { unsub1(); unsub2(); };
  }, []);

  const active = reports.filter((r) => r.status !== "resolved");
  const resolved = reports.filter((r) => r.status === "resolved");
  const available = volunteers.filter((v) => v.available);

  return (
    <div className="rs-layout">

      {/* Sidebar */}
      <aside className="rs-sidebar">
        <div className="rs-logo" style={{marginBottom:"2rem"}}>
          <span className="rs-logo-icon">⚡</span>
          <span className="rs-logo-text">ReliefSync</span>
        </div>
        <nav className="rs-nav">
          <button className="rs-nav-item rs-nav-active">Dashboard</button>
          <button className="rs-nav-item" onClick={() => navigate("/report")}>Submit Report</button>
          <button className="rs-nav-item" onClick={() => navigate("/assign")}>Task Assignment</button>
        </nav>
        <div className="rs-sidebar-footer">
          <div className="rs-user-pill">
            <img src={user?.photoURL} alt="" className="rs-avatar" />
            <span className="rs-user-name">{user?.displayName?.split(" ")[0]}</span>
          </div>
          <button className="rs-logout-btn" onClick={logout}>Sign out</button>
        </div>
      </aside>

      {/* Main */}
      <main className="rs-main">
        <header className="rs-page-header">
          <div>
            <h1 className="rs-page-title">Crisis dashboard</h1>
            <p className="rs-page-sub">Live overview · updates in real-time</p>
          </div>
          <button className="rs-primary-btn" onClick={() => navigate("/report")}>
            + New report
          </button>
        </header>

        {/* Stat cards */}
        <div className="rs-stat-grid">
          <div className="rs-stat-card">
            <span className="rs-stat-label">Active crises</span>
            <span className="rs-stat-num" style={{color:"#E24B4A"}}>{active.length}</span>
          </div>
          <div className="rs-stat-card">
            <span className="rs-stat-label">Available volunteers</span>
            <span className="rs-stat-num" style={{color:"#1D9E75"}}>{available.length}</span>
          </div>
          <div className="rs-stat-card">
            <span className="rs-stat-label">Total volunteers</span>
            <span className="rs-stat-num">{volunteers.length}</span>
          </div>
          <div className="rs-stat-card">
            <span className="rs-stat-label">Resolved today</span>
            <span className="rs-stat-num" style={{color:"#378ADD"}}>{resolved.length}</span>
          </div>
        </div>

        {/* Map placeholder */}
        <div className="rs-map-placeholder">
          <span className="rs-map-label">
            Live map · Google Maps integration added in Phase 5
          </span>
          <div className="rs-map-pins">
            {active.slice(0,6).map((r,i) => (
              <div key={r.id} className="rs-map-pin"
                style={{
                  left: `${15 + i * 14}%`,
                  top: `${25 + (i%3)*22}%`,
                  background: CATEGORY_COLOR[r.category],
                }}
                title={r.text?.slice(0,40)}
              />
            ))}
          </div>
        </div>

        {/* Active reports list */}
        <div className="rs-section-title">Active reports</div>
        <div className="rs-report-list">
          {active.length === 0 && (
            <div className="rs-empty">No active reports. All clear!</div>
          )}
          {active.map((r) => (
            <div key={r.id} className="rs-report-row"
              onClick={() => navigate("/assign", { state: { report: r } })}
            >
              <div
                className="rs-cat-badge"
                style={{
                  background: CATEGORY_COLOR[r.category] + "22",
                  color: CATEGORY_COLOR[r.category],
                  borderColor: CATEGORY_COLOR[r.category] + "44",
                }}
              >
                {CATEGORY_LABEL[r.category] ?? "Pending AI"}
              </div>
              <p className="rs-report-text">{r.text?.slice(0, 80)}…</p>
              <div className="rs-report-meta">
                {r.urgencyScore != null && (
                  <span className="rs-urgency">
                    Urgency {r.urgencyScore}/10
                    <span className="rs-urgency-bar">
                      <span style={{width: r.urgencyScore * 10 + "%", background: r.urgencyScore > 6 ? "#E24B4A" : r.urgencyScore > 3 ? "#BA7517" : "#1D9E75"}} />
                    </span>
                  </span>
                )}
                <span className="rs-status-pill rs-status-pill--{r.status}">{r.status}</span>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
