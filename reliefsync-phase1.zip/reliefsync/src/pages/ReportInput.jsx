// src/pages/ReportInput.jsx

import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";
import { addReport } from "../firebase/firestore";

export default function ReportInput() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [text, setText] = useState("");
  const [source, setSource] = useState("text");
  const [listening, setListening] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);
  const recognitionRef = useRef(null);

  // ── Voice input via Web Speech API ──
  function toggleVoice() {
    if (!("webkitSpeechRecognition" in window || "SpeechRecognition" in window)) {
      setError("Voice input not supported in this browser. Use Chrome.");
      return;
    }
    if (listening) {
      recognitionRef.current?.stop();
      setListening(false);
      return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const rec = new SR();
    rec.lang = "en-IN";
    rec.continuous = true;
    rec.interimResults = false;
    rec.onresult = (e) => {
      const transcript = Array.from(e.results)
        .map((r) => r[0].transcript)
        .join(" ");
      setText((prev) => prev + " " + transcript);
    };
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    recognitionRef.current = rec;
    rec.start();
    setListening(true);
    setSource("voice");
  }

  // ── CSV file upload ──
  function handleCSV(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const lines = ev.target.result.split("\n").slice(1); // skip header row
      const combined = lines
        .filter(Boolean)
        .map((l) => l.split(",").join(" "))
        .join(". ");
      setText(combined);
      setSource("csv");
    };
    reader.readAsText(file);
  }

  // ── Submit to Firestore ──
  async function handleSubmit() {
    if (!text.trim()) { setError("Please enter a report."); return; }
    setError(null);
    setSubmitting(true);
    try {
      await addReport(user.uid, text.trim(), source);
      setSuccess(true);
      setTimeout(() => navigate("/dashboard"), 1800);
    } catch (err) {
      setError("Failed to submit: " + err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="rs-layout">
      <aside className="rs-sidebar">
        <div className="rs-logo" style={{marginBottom:"2rem"}}>
          <span className="rs-logo-icon">⚡</span>
          <span className="rs-logo-text">ReliefSync</span>
        </div>
        <nav className="rs-nav">
          <button className="rs-nav-item" onClick={() => navigate("/dashboard")}>Dashboard</button>
          <button className="rs-nav-item rs-nav-active">Submit Report</button>
          <button className="rs-nav-item" onClick={() => navigate("/assign")}>Task Assignment</button>
        </nav>
      </aside>

      <main className="rs-main">
        <header className="rs-page-header">
          <div>
            <h1 className="rs-page-title">Submit field report</h1>
            <p className="rs-page-sub">Text, voice, or CSV · Gemini AI classifies automatically</p>
          </div>
        </header>

        {success ? (
          <div className="rs-success-banner">
            Report submitted. Gemini AI is classifying it now…
          </div>
        ) : (
          <div className="rs-form-card">

            {/* Input mode toggle */}
            <div className="rs-mode-row">
              {["text","voice","csv"].map((m) => (
                <button
                  key={m}
                  className={`rs-mode-btn ${source === m ? "rs-mode-btn--active" : ""}`}
                  onClick={() => setSource(m)}
                >
                  {m === "text" ? "Text" : m === "voice" ? "Voice" : "CSV upload"}
                </button>
              ))}
            </div>

            {/* Text area */}
            <textarea
              className="rs-textarea"
              rows={6}
              placeholder="Describe the crisis situation, location, number of people affected, urgent needs…"
              value={text}
              onChange={(e) => setText(e.target.value)}
            />

            {/* Controls row */}
            <div className="rs-controls-row">
              <button
                className={`rs-voice-btn ${listening ? "rs-voice-btn--active" : ""}`}
                onClick={toggleVoice}
              >
                {listening ? "Stop recording" : "Start voice input"}
              </button>

              <label className="rs-csv-label">
                Upload CSV
                <input type="file" accept=".csv" onChange={handleCSV} style={{display:"none"}} />
              </label>
            </div>

            {error && <p className="rs-error">{error}</p>}

            <div className="rs-form-footer">
              <span className="rs-char-count">{text.length} characters</span>
              <button
                className="rs-primary-btn"
                onClick={handleSubmit}
                disabled={submitting || !text.trim()}
              >
                {submitting ? "Submitting…" : "Submit report →"}
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
