// src/firebase/firestore.js
// All Firestore read/write helpers for ReliefSync

import {
  collection,
  addDoc,
  getDocs,
  onSnapshot,
  doc,
  updateDoc,
  query,
  orderBy,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "./config";

// ── REPORTS ──────────────────────────────────────────────────

/**
 * Add a new field report to Firestore.
 * @param {string} userId  - UID of submitting user
 * @param {string} text    - Raw report text (or transcription)
 * @param {string} source  - "text" | "voice" | "csv"
 */
export async function addReport(userId, text, source = "text") {
  return addDoc(collection(db, "reports"), {
    userId,
    text,
    source,
    status: "pending",        // pending → classified → assigned → resolved
    category: null,           // filled by Gemini Cloud Function
    urgencyScore: null,       // 1–10, filled by Gemini Cloud Function
    assignedVolunteer: null,
    createdAt: serverTimestamp(),
  });
}

/**
 * Listen to all reports in real-time (sorted newest first).
 * @param {function} callback - called with array of report objects
 * @returns unsubscribe function
 */
export function listenReports(callback) {
  const q = query(collection(db, "reports"), orderBy("createdAt", "desc"));
  return onSnapshot(q, (snap) => {
    const reports = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    callback(reports);
  });
}

/**
 * Update a report document (e.g. after AI classification).
 */
export async function updateReport(reportId, data) {
  return updateDoc(doc(db, "reports", reportId), data);
}

// ── VOLUNTEERS ────────────────────────────────────────────────

/**
 * Register a volunteer profile.
 * @param {object} volunteer - { userId, name, skills[], lat, lng, available }
 */
export async function addVolunteer(volunteer) {
  return addDoc(collection(db, "volunteers"), {
    ...volunteer,
    createdAt: serverTimestamp(),
  });
}

/**
 * Fetch all volunteers once.
 */
export async function getVolunteers() {
  const snap = await getDocs(collection(db, "volunteers"));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

/**
 * Listen to volunteers in real-time.
 */
export function listenVolunteers(callback) {
  return onSnapshot(collection(db, "volunteers"), (snap) => {
    const volunteers = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
    callback(volunteers);
  });
}

// ── ASSIGNMENTS ───────────────────────────────────────────────

/**
 * Create an assignment record linking a report to a volunteer.
 */
export async function createAssignment(reportId, volunteerId, volunteerName) {
  await updateDoc(doc(db, "reports", reportId), {
    status: "assigned",
    assignedVolunteer: { id: volunteerId, name: volunteerName },
    assignedAt: serverTimestamp(),
  });
  return addDoc(collection(db, "assignments"), {
    reportId,
    volunteerId,
    volunteerName,
    status: "active",
    createdAt: serverTimestamp(),
  });
}
