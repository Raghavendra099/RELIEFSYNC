// seed.js
// Run with: node seed.js   (after filling in your firebaseConfig below)
// This seeds 8 demo volunteers and 5 crisis reports for your hackathon demo.

import { initializeApp } from "firebase/app";
import { getFirestore, collection, addDoc, Timestamp } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const volunteers = [
  { name: "Ravi Kumar",    skills: ["medical","food"],    lat: 15.331, lng: 75.135, available: true  },
  { name: "Priya Sharma",  skills: ["shelter","food"],    lat: 15.342, lng: 75.120, available: true  },
  { name: "Arjun Nair",    skills: ["medical"],           lat: 15.318, lng: 75.148, available: true  },
  { name: "Sunita Bhat",   skills: ["food"],              lat: 15.355, lng: 75.110, available: false },
  { name: "Mohan Das",     skills: ["shelter"],           lat: 15.328, lng: 75.162, available: true  },
  { name: "Kavya Reddy",   skills: ["medical","shelter"], lat: 15.362, lng: 75.098, available: true  },
  { name: "Vikram Singh",  skills: ["food","shelter"],    lat: 15.310, lng: 75.175, available: true  },
  { name: "Ananya Joshi",  skills: ["medical"],           lat: 15.348, lng: 75.132, available: false },
];

const reports = [
  {
    text: "Flood in Naregal village. Around 40 families stranded. No food for 2 days. Need immediate help.",
    category: "food", urgencyScore: 9, status: "classified",
    lat: 15.331, lng: 75.140,
  },
  {
    text: "Elderly woman injured in Rona taluk landslide. Need medical attention urgently.",
    category: "medical", urgencyScore: 10, status: "classified",
    lat: 15.342, lng: 75.125,
  },
  {
    text: "15 families lost homes in Gadag fire. Sleeping on road. Need temporary shelter.",
    category: "shelter", urgencyScore: 8, status: "classified",
    lat: 15.318, lng: 75.115,
  },
  {
    text: "Water supply contaminated in Belavanki. Children showing symptoms. Need clean water and doctors.",
    category: "medical", urgencyScore: 7, status: "classified",
    lat: 15.355, lng: 75.130,
  },
  {
    text: "New report from field — details being verified.",
    category: null, urgencyScore: null, status: "pending",
    lat: 15.335, lng: 75.145,
  },
];

async function seed() {
  console.log("Seeding volunteers...");
  for (const v of volunteers) {
    await addDoc(collection(db, "volunteers"), { ...v, userId: "seed", createdAt: Timestamp.now() });
    console.log(" ✓", v.name);
  }

  console.log("\nSeeding reports...");
  for (const r of reports) {
    await addDoc(collection(db, "reports"), {
      ...r,
      userId: "seed",
      source: "text",
      assignedVolunteer: null,
      createdAt: Timestamp.now(),
    });
    console.log(" ✓", r.text.slice(0, 40));
  }

  console.log("\nDone! Open your Firebase console to verify.");
  process.exit(0);
}

seed().catch(console.error);
